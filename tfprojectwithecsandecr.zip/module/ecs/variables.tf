variable "vpc_id" {
  type = string
}
variable "private_subnets" {
  type = list(string)
}
variable "sg_ecs" {
  type = string
}
variable "alb_target_group" {
  type = string
}
